# セットアップガイド

このドキュメントでは、ベイスターズ自動情報サイトをセットアップする手順を説明します。

## 前提条件

- Node.js 18以上
- npm または pnpm
- GitHub アカウント
- Gemini API キー

## ステップ1: リポジトリのセットアップ

### 1.1 リポジトリを作成

GitHubで新しいリポジトリを作成します。リポジトリ名は `baystars-news-site` とします。

### 1.2 ローカルにクローン

```bash
git clone https://github.com/your-username/baystars-news-site.git
cd baystars-news-site
```

### 1.3 依存関係をインストール

```bash
npm install
```

## ステップ2: 環境変数の設定

### 2.1 Gemini API キーを取得

1. https://ai.google.dev にアクセス
2. 「Get API Key」をクリック
3. プロジェクトを選択または作成
4. APIキーをコピー

### 2.2 .envファイルを作成

`.env.example` をコピーして `.env` を作成します：

```bash
cp .env.example .env
```

`.env` ファイルを編集して、以下の値を設定します：

```
GEMINI_API_KEY=your_actual_api_key_here
SITE_URL=https://your-username.github.io/baystars-news-site
GITHUB_REPO=your-username/baystars-news-site
```

## ステップ3: ローカルでテスト

### 3.1 記事の収集をテスト

```bash
npm run fetch-articles
```

このコマンドで `articles/raw-articles.json` が生成されます。

### 3.2 記事の生成をテスト

```bash
npm run generate-articles
```

このコマンドで `articles/` ディレクトリに Markdown ファイルが生成されます。

### 3.3 サイトのビルドをテスト

```bash
npm run build-site
```

このコマンドで `public/index.html` が生成されます。

### 3.4 全処理を実行

```bash
npm start
```

## ステップ4: GitHub Actions の設定

### 4.1 シークレットを設定

GitHub リポジトリの設定画面で、以下のシークレットを追加します：

1. **Settings** → **Secrets and variables** → **Actions** をクリック
2. **New repository secret** をクリック
3. 以下のシークレットを追加：

| 名前 | 値 |
|------|-----|
| `GEMINI_API_KEY` | Gemini API キー |

### 4.2 GitHub Pages を有効化

1. **Settings** → **Pages** をクリック
2. **Source** で **Deploy from a branch** を選択
3. **Branch** で **gh-pages** を選択
4. **Save** をクリック

### 4.3 ワークフローを確認

`.github/workflows/auto-generate.yml` が正しく配置されていることを確認します。

## ステップ5: 初回実行

### 5.1 ワークフローを手動実行

1. GitHub リポジトリの **Actions** タブをクリック
2. **自動記事生成とデプロイ** をクリック
3. **Run workflow** をクリック

### 5.2 実行結果を確認

ワークフローが成功すると：
- `articles/` に新しい Markdown ファイルが生成されます
- `public/` に HTML ファイルが生成されます
- GitHub Pages でサイトが公開されます

## ステップ6: 自動実行の確認

デフォルトでは、毎日夜間（日本時間 22:00）に自動実行されます。

スケジュール実行の確認方法：
1. **Actions** タブで実行履歴を確認
2. **Scheduled** フィルターで確認

## トラブルシューティング

### 記事が生成されない場合

1. Gemini API キーが正しく設定されているか確認
2. API の利用制限に達していないか確認
3. ワークフローのログを確認

### GitHub Pages が表示されない場合

1. リポジトリの **Settings** → **Pages** で **gh-pages** ブランチが選択されているか確認
2. ワークフローが成功しているか確認
3. キャッシュをクリアして再度アクセス

### API エラーが発生する場合

1. インターネット接続を確認
2. ニュースソースのサイト構造が変わっていないか確認
3. セレクタを更新する必要があるかもしれません

## カスタマイズ

### 記事の生成スタイルを変更

`scripts/generate-articles.js` の `prompt` 変数を編集して、記事生成のプロンプトをカスタマイズできます。

### ニュースソースを追加

`scripts/fetch-articles.js` に新しい関数を追加して、ニュースソースを追加できます。

### デザインを変更

`scripts/build-site.js` の `generateHTML` 関数内の CSS を編集して、デザインをカスタマイズできます。

### 実行スケジュールを変更

`.github/workflows/auto-generate.yml` の `cron` 式を編集して、実行スケジュールを変更できます。

例：毎日午前10時に実行
```yaml
cron: '0 1 * * *'  # UTC 1:00 = JST 10:00
```

## サポート

問題が発生した場合は、GitHub Issues で報告してください。

