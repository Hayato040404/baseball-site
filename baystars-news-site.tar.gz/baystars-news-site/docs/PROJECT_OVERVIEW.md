# プロジェクト概要

## ベイスターズ自動情報サイト

横浜DeNAベイスターズの最新情報を毎日自動で収集し、AI（Gemini）で記事を生成して公開する完全自動化ニュースサイトです。

## プロジェクトの特徴

### 🤖 完全自動化

- **GitHub Actions**: 毎日夜間に自動実行
- **記事収集**: 複数のソースから自動収集
- **AI記事生成**: Gemini APIで自動生成
- **自動公開**: GitHub Pagesで自動公開

### 📰 複数ソース対応

以下のソースから自動的に情報を収集します:

1. **ベイスターズ公式サイト** - 最新ニュース、選手情報
2. **Yahoo!ニュース** - スポーツニュース
3. **スポーツナビ** - 試合結果、成績
4. **Google ニュース** - 総合ニュース
5. **日刊スポーツ** - スポーツニュース
6. **毎日新聞** - 野球関連ニュース

### 🎨 モバイルフレンドリー

- ベイスターズの青（#003DA5）を基調としたデザイン
- レスポンシブ対応で、スマートフォン・タブレット・PCで最適表示
- シンプルで読みやすいレイアウト

### 🔄 継続的な更新

- 毎日夜間に自動実行
- 新しい記事が自動的にメニューに表示
- 記事の履歴を自動管理

## 技術スタック

### フロントエンド

- **HTML5**: セマンティックマークアップ
- **CSS3**: モダンなスタイリング、グラデーション、フレックスボックス
- **JavaScript**: 軽量な機能実装

### バックエンド

- **Node.js**: スクリプト実行環境
- **npm**: パッケージ管理

### 外部サービス

- **Google Gemini API**: AI記事生成
- **GitHub Actions**: 自動実行スケジューリング
- **GitHub Pages**: ホスティング

### ライブラリ

- **cheerio**: HTMLスクレイピング
- **@google/generative-ai**: Gemini API クライアント
- **front-matter**: Markdownメタデータ解析
- **dotenv**: 環境変数管理

## ファイル構成

```
baystars-news-site/
├── .github/
│   └── workflows/
│       └── auto-generate.yml          # GitHub Actions ワークフロー
├── articles/                           # 生成された記事（Markdown）
│   ├── 2025-10-23-*.md                # 日付付き記事ファイル
│   ├── raw-articles.json              # 収集した記事の生データ
│   └── index.json                     # 記事インデックス
├── public/                             # 公開ファイル（GitHub Pages）
│   ├── index.html                     # メインページ
│   └── articles.json                  # 記事一覧JSON
├── scripts/
│   ├── fetch-articles.js              # 記事収集スクリプト
│   ├── generate-articles.js           # AI記事生成スクリプト
│   └── build-site.js                  # サイトビルドスクリプト
├── docs/
│   ├── QUICK_START.md                 # クイックスタート
│   ├── SETUP.md                       # 詳細セットアップ
│   ├── DEPLOYMENT.md                  # デプロイメント
│   └── PROJECT_OVERVIEW.md            # このファイル
├── package.json                        # npm設定
├── .gitignore                          # Git除外設定
└── README.md                           # プロジェクト説明
```

## ワークフロー

### 記事生成のフロー

```
1. GitHub Actions トリガー
   ↓
2. 複数のソースから記事を収集
   - ベイスターズ公式サイト
   - Yahoo!ニュース
   - スポーツナビ
   - Google ニュース
   - 日刊スポーツ
   - 毎日新聞
   ↓
3. 重複を削除してJSON保存
   ↓
4. Gemini APIで各記事を処理
   ↓
5. Markdownファイルとして保存
   ↓
6. サイトをビルド（HTML生成）
   ↓
7. GitHub Pagesにデプロイ
   ↓
8. サイト自動更新完了
```

## 実行スケジュール

**デフォルト**: 毎日夜間 22:00（日本時間）

```yaml
cron: '0 13 * * *'  # UTC 13:00 = JST 22:00
```

カスタマイズ可能:
- `.github/workflows/auto-generate.yml` の `cron` 式を変更

## API利用

### Gemini API

- **用途**: 記事の自動生成
- **モデル**: gemini-2.0-flash（デフォルト）
- **無料枠**: 1分あたり15リクエスト
- **有料プラン**: より多くのリクエストが可能

### GitHub API

- **用途**: リポジトリへのコミット、Pages デプロイ
- **認証**: GitHub Actions の自動トークン

## セキュリティ

### シークレット管理

- **Gemini API キー**: GitHub Secrets で安全に管理
- **GitHub Token**: GitHub Actions が自動提供

### アクセス制御

- ワークフローの権限は最小限に制限
- 読み取り専用の外部ソースからのみ情報取得

## パフォーマンス

### 最適化

- **キャッシング**: npm キャッシュで高速化
- **並列処理**: 複数ソースの同時取得
- **ファイルサイズ**: 最小限の HTML/CSS

### スケーラビリティ

- 記事数が増えても安定動作
- 最新100件の記事を保持
- 古い記事は自動削除

## カスタマイズ例

### スケジュール変更

毎日午前10時に実行:
```yaml
cron: '0 1 * * *'  # UTC 1:00 = JST 10:00
```

### ニュースソース追加

`scripts/fetch-articles.js` に新しい関数を追加:
```javascript
async function fetchNewSource() {
  // スクレイピングロジック
  return articles;
}
```

### デザイン変更

`scripts/build-site.js` の CSS を編集

## トラブルシューティング

### よくある問題

| 問題 | 原因 | 解決方法 |
|------|------|--------|
| ワークフロー失敗 | API キー未設定 | GitHub Secrets を確認 |
| 記事が生成されない | API 利用制限 | 有料プランへアップグレード |
| サイトが表示されない | Pages 設定未完了 | Settings → Pages を確認 |
| 記事が古いまま | スケジュール未実行 | Actions タブで手動実行 |

## 今後の拡張予定

- [ ] Twitter/X API 統合
- [ ] 記事のカテゴリ分類
- [ ] 検索機能
- [ ] コメント機能
- [ ] RSS フィード
- [ ] モバイルアプリ

## ライセンス

MIT License

## サポート

問題が発生した場合は、GitHub Issues で報告してください。

## 関連ドキュメント

- [クイックスタートガイド](./QUICK_START.md)
- [詳細セットアップガイド](./SETUP.md)
- [デプロイメントガイド](./DEPLOYMENT.md)
- [README](../README.md)

