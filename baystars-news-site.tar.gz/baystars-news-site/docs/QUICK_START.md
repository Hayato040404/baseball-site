# クイックスタートガイド

ベイスターズ自動情報サイトをGitHub Pagesで公開するための最速セットアップガイドです。

## 必要なもの

- GitHub アカウント
- Gemini API キー（提供済み）

## ステップ1: GitHub リポジトリを作成

1. https://github.com/new にアクセス
2. **Repository name** に `baystars-news-site` と入力
3. **Public** を選択
4. **Create repository** をクリック

## ステップ2: ローカルリポジトリをプッシュ

```bash
cd /home/ubuntu/baystars-news-site

# リモートリポジトリを追加
git remote add origin https://github.com/your-username/baystars-news-site.git
git branch -M main
git push -u origin main
```

※ `your-username` は自分のGitHubユーザー名に置き換えてください

## ステップ3: GitHub Secrets を設定

1. リポジトリページで **Settings** をクリック
2. 左側メニューから **Secrets and variables** → **Actions** をクリック
3. **New repository secret** をクリック
4. 以下の情報を入力:
   - **Name**: `GEMINI_API_KEY`
   - **Secret**: `AIzaSyCCJfiO3TSRfJ2ywY5Cj-HLsQWNMFpyWe0`
5. **Add secret** をクリック

## ステップ4: GitHub Pages を有効化

1. リポジトリページで **Settings** をクリック
2. 左側メニューから **Pages** をクリック
3. **Source** セクションで:
   - **Deploy from a branch** を選択
   - **Branch** で **gh-pages** を選択
   - **/(root)** を選択
4. **Save** をクリック

## ステップ5: ワークフローを実行

1. リポジトリの **Actions** タブをクリック
2. 左側から **自動記事生成とデプロイ** を選択
3. **Run workflow** をクリック
4. **Run workflow** を確認

## ステップ6: サイトにアクセス

数分待機後、以下のURLでサイトが公開されます:

```
https://your-username.github.io/baystars-news-site/
```

## 自動実行の確認

デフォルトでは毎日夜間（日本時間 22:00）に自動実行されます。

**スケジュール実行の確認方法**:
1. **Actions** タブをクリック
2. 左側から **自動記事生成とデプロイ** を選択
3. 実行履歴を確認

## トラブルシューティング

### ワークフローが失敗する場合

1. **Actions** タブで失敗したワークフローをクリック
2. 各ステップのログを確認
3. エラーメッセージを確認して対応

### GitHub Pages が表示されない場合

1. **Settings** → **Pages** で **gh-pages** ブランチが選択されているか確認
2. ワークフローが成功しているか確認（✓ マークが付いているか）
3. ブラウザのキャッシュをクリアして再度アクセス

## カスタマイズ

### 実行スケジュールを変更

`.github/workflows/auto-generate.yml` の `cron` 式を編集:

```yaml
schedule:
  - cron: '0 13 * * *'  # UTC 13:00 = JST 22:00
```

例：毎日午前10時に実行
```yaml
schedule:
  - cron: '0 1 * * *'  # UTC 1:00 = JST 10:00
```

### デザインを変更

`scripts/build-site.js` の `generateHTML` 関数内の CSS を編集

### ニュースソースを追加

`scripts/fetch-articles.js` に新しい関数を追加

## 次のステップ

- [詳細なセットアップガイド](./SETUP.md)
- [デプロイメントガイド](./DEPLOYMENT.md)
- [README](../README.md)

## サポート

問題が発生した場合は、GitHub Issues で報告してください。

