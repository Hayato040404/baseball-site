# デプロイメントガイド

このドキュメントでは、ベイスターズ自動情報サイトを GitHub Pages にデプロイする手順を説明します。

## 概要

このプロジェクトは GitHub Actions を使用して自動的に GitHub Pages にデプロイされます。

デプロイメントフロー：
1. GitHub Actions ワークフローが実行
2. 記事を収集
3. AI で記事を生成
4. サイトをビルド
5. `gh-pages` ブランチにプッシュ
6. GitHub Pages で自動公開

## デプロイメント前のチェックリスト

- [ ] リポジトリが GitHub に作成されている
- [ ] Gemini API キーが設定されている
- [ ] GitHub Pages が有効化されている
- [ ] ワークフローファイルが正しく配置されている
- [ ] ローカルでテストが成功している

## 手動デプロイメント

### 方法1: GitHub Actions で手動実行

1. GitHub リポジトリの **Actions** タブをクリック
2. 左側のワークフロー一覧から **自動記事生成とデプロイ** をクリック
3. **Run workflow** ボタンをクリック
4. **Run workflow** を確認

### 方法2: ローカルでビルドして手動プッシュ

```bash
# 記事を収集
npm run fetch-articles

# AI で記事を生成
npm run generate-articles

# サイトをビルド
npm run build-site

# 変更をコミット
git add articles/ public/
git commit -m "Manual build: $(date)"

# GitHub にプッシュ
git push origin main

# gh-pages ブランチにプッシュ（GitHub Pages 用）
git subtree push --prefix public origin gh-pages
```

## 自動デプロイメントの設定

### GitHub Pages の設定

1. リポジトリの **Settings** をクリック
2. 左側メニューから **Pages** をクリック
3. **Source** セクションで：
   - **Deploy from a branch** を選択
   - **Branch** で **gh-pages** を選択
   - **/(root)** を選択
4. **Save** をクリック

### ワークフロー設定の確認

`.github/workflows/auto-generate.yml` で以下を確認：

```yaml
- name: GitHub Pagesにデプロイ
  uses: peaceiris/actions-gh-pages@v3
  with:
    github_token: ${{ secrets.GITHUB_TOKEN }}
    publish_dir: ./public
```

## デプロイメント後の確認

### 1. ワークフロー実行結果を確認

1. **Actions** タブをクリック
2. 最新の実行結果を確認
3. すべてのステップが成功（✓）していることを確認

### 2. GitHub Pages でサイトを確認

デプロイメント後、以下の URL でサイトにアクセスできます：

```
https://your-username.github.io/baystars-news-site/
```

### 3. 記事が表示されているか確認

- ホームページに最新の記事が表示されているか
- 記事のタイトル、日付、カテゴリが正しく表示されているか
- リンクが正しく機能しているか

## トラブルシューティング

### デプロイメントが失敗する場合

#### ワークフローログを確認

1. **Actions** タブをクリック
2. 失敗したワークフロー実行をクリック
3. 各ステップのログを確認

#### よくあるエラー

**エラー: "GEMINI_API_KEY is not set"**
- 解決: GitHub Secrets に `GEMINI_API_KEY` が設定されているか確認

**エラー: "Permission denied"**
- 解決: ワークフローの `permissions` が正しく設定されているか確認

**エラー: "gh-pages branch not found"**
- 解決: GitHub Pages の設定で `gh-pages` ブランチが選択されているか確認

### サイトが表示されない場合

#### 1. GitHub Pages の設定を確認

1. **Settings** → **Pages** をクリック
2. **Source** が **Deploy from a branch** に設定されているか確認
3. **Branch** が **gh-pages** に設定されているか確認

#### 2. ブランチが存在するか確認

```bash
git branch -r | grep gh-pages
```

#### 3. キャッシュをクリア

- ブラウザのキャッシュをクリア
- 数分待機（GitHub Pages の反映に時間がかかる場合がある）

### 記事が生成されない場合

#### Gemini API の利用制限を確認

1. https://ai.google.dev にアクセス
2. API の利用状況を確認
3. 利用制限に達していないか確認

#### ニュースソースの確認

ニュースソースのサイト構造が変わった可能性があります：

```bash
npm run fetch-articles
```

を実行して、エラーメッセージを確認してください。

## パフォーマンス最適化

### 1. キャッシュの活用

ワークフローで npm キャッシュを使用しています：

```yaml
- uses: actions/setup-node@v4
  with:
    cache: 'npm'
```

### 2. 並列処理

記事の収集を並列処理で高速化しています：

```javascript
const [baystarArticles, yahooArticles, twitterArticles] = await Promise.all([
  fetchBaystarNews(),
  fetchYahooNews(),
  fetchTwitterNews()
]);
```

### 3. ファイルサイズの最適化

生成される HTML は最小限に保たれています。

## セキュリティ

### 1. シークレットの管理

Gemini API キーは GitHub Secrets で安全に管理されています。

### 2. トークンの権限

ワークフローで使用される `GITHUB_TOKEN` は最小限の権限に制限されています：

```yaml
permissions:
  contents: write
  pages: write
  id-token: write
```

### 3. リポジトリの保護

本番環境では以下を推奨します：

- ブランチ保護ルールを設定
- コードレビューを必須にする
- 定期的にセキュリティアップデートを確認

## カスタムドメインの設定

GitHub Pages でカスタムドメインを使用する場合：

1. **Settings** → **Pages** をクリック
2. **Custom domain** に自分のドメインを入力
3. DNS レコードを設定

詳細は [GitHub Pages のドキュメント](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site) を参照してください。

## まとめ

このプロジェクトは GitHub Actions と GitHub Pages を使用して、完全に自動化されたデプロイメントを実現しています。

初回セットアップ後は、毎日夜間に自動的に記事が生成・公開されます。

