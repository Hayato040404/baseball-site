---
title: "APP2025/10/23『横浜DeNAベイスターズ BAY BLUE FESTIVAL ～ BAYSTARS FUN! DAYS ～ Supported by ありあけハーバー』にて、「MY BAYSTARS」dianaカードお渡し会が抽選で当たるキャンペーン開催&リアル化カード受取ブース出店！"
date: "2025-10-23"
category: "ベイスターズニュース"
source: "ベイスターズ公式"
sourceUrl: "https://www.baystars.co.jp/news/2025/10/1023_05.php"
author: "AI記事生成"
---

## APP2025/10/23『横浜DeNAベイスターズ BAY BLUE FESTIVAL ～ BAYSTARS FUN! DAYS ～ Supported by ありあけハーバー』にて、「MY BAYSTARS」dianaカードお渡し会が抽選で当たるキャンペーン開催&リアル化カード受取ブース出店！

**ソース**: ベイスターズ公式  
**日付**: 2025/10/23

### ニュース概要

このニュースは、ベイスターズに関する最新情報です。詳細については、以下のリンクをご確認ください。

[元の記事を読む](https://www.baystars.co.jp/news/2025/10/1023_05.php)

### ベイスターズファンの視点

ベイスターズの活動に関する重要なニュースが報告されました。このような情報は、ファンにとって重要な関心事です。

チームの最新動向に注目しながら、今後の試合や選手の活躍を応援していきましょう。

#ベイスターズ #横浜DeNA #プロ野球